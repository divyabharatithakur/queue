package queue.com;


	// Java program to add elements
	// to a Queue
	  
	import java.util.*;
	  
	public class AddingElements {
	  
	    public static void main(String args[])
	    {
	        Queue<String> pq = new PriorityQueue<>();
	  
	        pq.add("Geeks");
	        pq.add("For");
	        pq.add("Geeks");
	  
	        System.out.println(pq);
	    }
	
}
